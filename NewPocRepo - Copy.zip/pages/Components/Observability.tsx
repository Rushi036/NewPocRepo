import React from "react";

const Observability = () => {
  return (
    <div>
      <div className="text-xl border-b-2 px-4 border-slate-400 pb-2">
        Observability
      </div>
    </div>
  );
};

export default Observability;
