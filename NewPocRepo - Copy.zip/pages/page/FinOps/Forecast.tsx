import React from "react";

const Forecast = () => {
  return (
    <div className="w-full h-[52vh] flex justify-center items-center text-4xl font-sans ">
      COMING SOON
    </div>
  );
};

export default Forecast;
