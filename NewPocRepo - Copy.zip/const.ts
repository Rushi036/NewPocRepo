// export const baseURL = "http://localhost:8000/";
export const baseURL = "http://10.47.98.164:9250/";
export const finopsBaseUrl = "http://95.217.191.79:8001"
export const finopsServerBaseUrl = "http://10.47.98.164:9201"
export const localHostBaseUrl = "http://localhost:9201"
